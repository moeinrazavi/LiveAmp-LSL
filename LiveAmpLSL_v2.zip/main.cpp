
#include <windows.h>
#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <lsl_cpp.h>
#include <thread>

// contains templated, easy to use functions for controlling the
// functions exposed through AmplifierSDK.h
#include "SDK.h"

// note: this header is already supplied by SDK.h
// it is explicitly re-included for completeness' sake
#include "AmplifierSDK.h"

// class for handling raw amplifer data
#include "RawDataHandlerExample.h"

#include <random>

// lsl::stream_info info("LiveAmpEEG", "EEG", 23, 500);
// lsl::stream_outlet outlet(info);

std::vector<std::pair<std::string, std::string>> m_vpAmpDetails;
static CAmplifier amp;
CRITICAL_SECTION m_CriticalSection;
bool m_bIsThreadRunning;

// forward declaration needed for some functions:
void CheckImpedances(std::vector<float>& vfImpVals);

// struct EEG_Data {

	// float ch[23];
// };

void PrintChannelValues()
{
	// first setup the amplifier and put it into acquisition mode
	RawDataHandler rdh(amp);
	amp.StartAcquisition(RM_NORMAL);

	// now parse the data (look into RawDataHanlers.h for details)
	// std::vector<std::vector<float>> vvfData;
	
	double channel_data[23];
	//int nChoice = -1;
	int nChoice = 0;
	// double channels[23];
	while (nChoice != 1)
	{

		if (nChoice == 0)
		{
			// rdh.ParseRawData(amp, vvfData);
			rdh.ParseRawData(amp);
			int nChCnt = 0;
			// std::vector<float> vfData = vvfData[0];
			outlet.push_sample(channel_data);
		}
	}
	// finish up
	amp.StopAcquisition();

}

struct RecordingParams {
	int nSampleSize;
	float fSR;
	int32_t nBufferLen;
};

// synchronized function for writing data to file
DWORD WINAPI RecordFunc(void* pVoid)
{
	RecordingParams pRecordingParams = *(RecordingParams*)pVoid;
	int nLast = 0;
	std::vector<BYTE> Buffer;

	Buffer.resize(pRecordingParams.nBufferLen);
	InitializeCriticalSection(&m_CriticalSection);
	while (m_bIsThreadRunning)
	{
		try
		{
			int nRet = AMP_OK;
			int nLSLRetVal = 0;
			int nRecRetVal = 0;
			EnterCriticalSection(&m_CriticalSection);
			nRet = amp.GetData(&Buffer[0], (int)Buffer.size(), (int)Buffer.size());

			if (nRet > 0)
				nRecRetVal = CStorage::StoreDataBlock(amp.m_hAmplifier, &Buffer[0], nRet);

			LeaveCriticalSection(&m_CriticalSection);

		}
		catch (const std::exception&)
		{
			LeaveCriticalSection(&m_CriticalSection);
			return FALSE;
		}

	}
	DeleteCriticalSection(&m_CriticalSection);
	return TRUE;
}

void Record()
{
	std::string sFileName;
	HANDLE hThread = NULL;
	m_bIsThreadRunning = false;
	int nSecondsCtr = 0;

	// get the necessary information from the amplifier
	RawDataHandler rdh(amp);
	int nSampleSize = rdh.getSampleSize();
	float fBaseSR;
	float fSubSampleDevisor;
	int nRes = amp.GetProperty(fBaseSR, DPROP_F32_BaseSampleRate);
	if (nRes != AMP_OK)
	{
		// handle error
		return;
	}
	nRes = amp.GetProperty(fSubSampleDevisor, DPROP_F32_SubSampleDivisor);
	if (nRes != AMP_OK)
	{
		// handle error
		return;
	}

	// pack the information
	RecordingParams pRecordingParams;
	pRecordingParams.fSR = fBaseSR / fSubSampleDevisor;
	pRecordingParams.nSampleSize = nSampleSize;
	pRecordingParams.nBufferLen = (int)(pRecordingParams.fSR * .2 * 200);

	int nCheckImpedances = 0;
	std::vector<float> vfImpVals;
	std::cout << "\nCheck impedances?:\n\t0: no\n\t1: yes\n>> ";
	std::cin >> nCheckImpedances;
	if (nCheckImpedances != 0)
		CheckImpedances(vfImpVals);

	std::cout << "\n\nPlease enter filename, e.g. \'rec01.eeg\' (.dat, .vmrk, and .vhdr files will be written to this directory):\n" << ">> ";
	std::cin >> sFileName;

	// initialize the recording---the final argument is whether or not to record to the SD card in the case of LiveAmp
	nRes = CStorage::StartRecording(amp, ("./" + sFileName).c_str(), "optional comment", false);
	if (nRes != AMP_OK)
	{
		// handle error
		return;
	}

	// start data flow
	nRes = amp.StartAcquisition(RecordingMode::RM_NORMAL);
	if (nRes != AMP_OK)
	{
		// handle error
		return;
	}

	// launch recording thread
	m_bIsThreadRunning = true;
	hThread = CreateThread(NULL, 0, RecordFunc, &pRecordingParams, 0, NULL);
	if (hThread == 0)
	{
		std::cout << "Error spawning recording thread\n";
		return;
	}

	// wait for about 10 seconds
	while (nSecondsCtr < 10)
	{
		Sleep(1000);
		std::cout << "\n\t...writing...";
		nSecondsCtr++;
	}

	// kill the thread
	if (m_bIsThreadRunning == true)
	{
		m_bIsThreadRunning = false;
		WaitForSingleObject(hThread, INFINITE);
	}
	std::cout << "\nDone\n";

	// stop data flow
	nRes = amp.StopAcquisition();
	if (nRes != AMP_OK)
	{
		// handle error
		return;
	}

}

void CheckImpedances(std::vector<float>& vfImpVals)
{
	BOOL bChannelSupportImp;
	int nRet;
	int nAvailableChannels;
	int nImpChns = 0;
	std::vector<float> vfImpData;

	amp.GetProperty(nAvailableChannels, DPROP_I32_AvailableChannels);
	for (int i = 0; i < nAvailableChannels; i++)
	{
		nRet = amp.GetProperty(bChannelSupportImp, i, CPROP_B32_ImpedanceMeasurement);
		if (!bChannelSupportImp || nRet < 0)
			continue;

		nImpChns++;
	}

	if (nImpChns == 0)
	{
		std::cout << "\nNo impedance data available. Are any electrodes attached?";
		return;
	}
	// this is how to gather impedance data:
	vfImpVals.resize(nImpChns, -1.0);
	// there are 2*nChns + 1 values of raw data to parse 
	nImpChns = 2 * (nImpChns + 1);
	vfImpData.resize(nImpChns, -1.0);
	std::cout << "\n\nImpedance data: ";
	int nCnt = 0;
	amp.StartAcquisition(RM_IMPEDANCE);
	nRet = -1;
	std::string sAmpFamily;
	int nIsRef = 0;
	while (nRet <= AMP_OK)
		nRet = amp.GetData(&vfImpData[0], vfImpData.size() * sizeof(float), vfImpData.size() * sizeof(float));
	float fVal;
	if (nRet > AMP_OK)
	{
		// note that for actiCHamp, a reference channel must be chosen 
		// in LiveAmp, there is a dedicated reference electrode
		fVal = vfImpData[0];
		std::cout << "\nGnd: " << fVal;
		fVal = vfImpData[1];
		std::cout << "\nRef: " << fVal;
		for (std::vector<float>::iterator it = vfImpData.begin() + 2;
			it != vfImpData.end();
			it += 2)
		{
			fVal = (*(it + 1) < 0) ? *it : *it - *(it + 1); // this is because electrodes may be bipolar
			std::cout << "\nCh_" << nCnt << ": " << fVal;
			nCnt++;

		}
	}
	amp.StopAcquisition();

}

// example for how to change a device property
void ChangeSampleRate()
{

	float fSR, fSSD;
	int nIdx;
	int nRes;

	// SDK structures for property ranges (templated)
	PropertyRange<float> prAvailableSampleRates;
	PropertyRange<float> prAvailableSubSampleDivisors;
	// get the available values for this property
	nRes = amp.GetPropertyRange(prAvailableSampleRates, DPROP_F32_BaseSampleRate);
	if (nRes != AMP_OK)
	{
		std::cout << "\nERROR in GetPropertyRange BaseSampleRate:\t" << nRes;
		return;
	}
	// get the available values for this property
	nRes = amp.GetPropertyRange(prAvailableSubSampleDivisors, DPROP_F32_SubSampleDivisor);
	if (nRes != AMP_OK)
	{
		std::cout << "\nERROR in GetPropertyRange SubSampleDivisor:\t" << nRes;
		return;
	}
	bool bHasSSD = true;
	if (prAvailableSubSampleDivisors.ByteLength == 0)
	{
		bHasSSD = false;
		fSSD = 1.0;
	}
	// queery the current sampling rates
	nRes = amp.GetProperty(fSR, DPROP_F32_BaseSampleRate);
	if (nRes != AMP_OK)
	{
		std::cout << "\nERROR in GetProperty BaseSampleDivisor:\t" << nRes;
		return;
	}
	std::cout << "\n\tCurrent Base Sample Rate: " << fSR;
	amp.GetProperty(fSSD, DPROP_F32_SubSampleDivisor);
	if (nRes != AMP_OK)
	{
		std::cout << "\nERROR in GetProperty SubSampleDivisor:\t" << nRes;
		return;
	}
	if (bHasSSD)std::cout << "\n\tCurrent Sub-Sample Divisor: " << fSSD;
	std::cout << "\n\tCurrent Effective Sampling Rate: " << (int)(fSR / fSSD);

	nRes = amp.GetProperty(fSR, DPROP_F32_BaseSampleRate);
	if (nRes != AMP_OK)
	{
		std::cout << "\nERROR in GetProperty BaseSampleRate:\t" << nRes;
		return;
	}

	int nAvailable = prAvailableSampleRates.ByteLength / sizeof(float);
	// std::cout << "\n\nChoose from available Base Sample Rates:";
	std::cout << "\n\nSampling Rate Set on 500 Hz...";
	// for (int i = 0; i < nAvailable; i++)
		// std::cout << "\n\t" << i << ": " << prAvailableSampleRates.RangeArray[i] << " ";
	std::cout << "\n>> ";
	// std::cin >> nIdx;

	// nIdx -> 0: 250, 1: 500, 2: 1000
	nIdx = 1;
	nRes = amp.SetProperty(prAvailableSampleRates.RangeArray[nIdx], DPROP_F32_BaseSampleRate);
	if (nRes != AMP_OK)
	{
		std::cout << "\nERROR in SetProperty BaseSampleRate:\t" << nRes;
		return;
	}

	nRes = amp.GetProperty(fSR, DPROP_F32_BaseSampleRate);
	if (nRes != AMP_OK)
	{
		std::cout << "\nERROR in GetProperty BaseSampleRate:\t" << nRes;
		return;
	}
	std::cout << "\n\tCurrent Base Sample Rate: " << fSR;

	if (bHasSSD)
	{
		nRes = amp.GetProperty(fSSD, DPROP_F32_SubSampleDivisor);
		if (nRes != AMP_OK)
		{
			std::cout << "\nERROR in GetProperty SubSampleDivisor:\t" << nRes;
			return;
		}
		nAvailable = prAvailableSubSampleDivisors.ByteLength / sizeof(float);
		std::cout << "\n\nChoose from available Sub-Sample Divisors:";
		for (int i = 0; i < nAvailable; i++)
			std::cout << "\n\t" << i << ": " << prAvailableSubSampleDivisors.RangeArray[i] << " ";
		std::cout << "\n>> ";
		std::cin >> nIdx;
		nRes = amp.SetProperty(prAvailableSubSampleDivisors.RangeArray[nIdx], DPROP_F32_SubSampleDivisor);
		if (nRes != AMP_OK)
		{
			std::cout << "\nERROR in SetProperty SubSampleDivisor:\t" << nRes;
			return;
		}

		nRes = amp.GetProperty(fSSD, DPROP_F32_SubSampleDivisor);
		if (nRes != AMP_OK)
		{
			std::cout << "\nERROR in GetProperty SubSampleDivisor:\t" << nRes;
			return;
		}
		std::cout << "\n\tCurrent Sub-Sample Divisor: " << fSSD;
	}
	std::cout << "\n\tCurrent Effective Sampling Rate: " << (int)(fSR / fSSD) << endl;

}

void DisplaySomeProperties()
{
	std::string sProp;
	int nProp;
	float fProp;
	int nRes;
	t_VersionNumber tvnProp;

	amp.StartAcquisition(RM_NORMAL);

	// queery device a few properties
	std::cout << "\n\nSome Device Properties (for a complete list see Amplifier_LIB.h):";
	amp.GetProperty(tvnProp, DPROP_TVN_HardwareRevision);
	std::cout << "\n\tHardwareRevision:\t" << tvnProp.Major << "." <<
		tvnProp.Minor << "." << tvnProp.Build << "." << tvnProp.Revision;
	amp.GetProperty(nProp, DPROP_I32_AvailableModules);
	std::cout << "\n\tAvailableModuls:\t" << nProp;

	// a few module properties
	std::cout << "\n\nSome Module Properties for module 0:";
	amp.GetProperty(sProp, 0, MPROP_CHR_Type);
	std::cout << "\n\tType:\t" << sProp;
	amp.GetProperty(nProp, 0, MPROP_I32_UseableChannels);
	std::cout << "\n\tUsableChannels:\t" << nProp;
	std::cout << "\n\nSome Channel Properties for channel 0:";

	// a few channel properties
	amp.GetProperty(nProp, 0, CPROP_I32_ChannelNumber);
	std::cout << "\n\tChannelNumber:\t" << nProp;
	amp.GetProperty(fProp, 0, CPROP_F32_Resolution);
	std::cout << "\n\tResolution:\t" << fProp;

	amp.StopAcquisition();

}

void ConnectToAmp(int nIdx)
{


	amp.Close();
	amp.m_hAmplifier = NULL;
	int nRes = amp.Open(nIdx);
	if (nRes != AMP_OK)
	{
		std::cout << "\nERROR in opening amplifier:\t" << nRes;
		return;
	}
	//Retrieve Versions 
	VersionNumber apiVersion, libVersion;
	CDllHandler::GetInfo(InfoType::eAPIVersion, (void*)&apiVersion, sizeof(t_VersionNumber));
	CDllHandler::GetInfo(InfoType::eLIBVersion, (void*)&libVersion, sizeof(t_VersionNumber));
	std::cout << "\n\nConnected to: " << m_vpAmpDetails[nIdx].first << " " << m_vpAmpDetails[nIdx].second << ": ";
	std::cout << "\n\tAPI Version " <<
		apiVersion.Major << "." <<
		apiVersion.Minor << "." <<
		apiVersion.Build << "." <<
		apiVersion.Revision;

	std::cout << "\n\tLibrary Version " <<
		libVersion.Major << "." <<
		libVersion.Minor << "." <<
		libVersion.Build << "." <<
		libVersion.Revision;
	std::cout << "\n";

}

int DisplayAmpInfo(int nCount)
{
	std::string sSerialNumber;
	std::string sType;
	std::pair<std::string, std::string> pssAmpDetails;
	CAmplifier amp;
	m_vpAmpDetails.clear();
	int nRes;
	for (int i = 0; i < nCount; i++)
	{
		// open an amplifier using CAmplifier class from SDK.h
		// then query the device for serial number and device type
		nRes = amp.Open(i);
		if (nRes != AMP_OK)
		{
			std::cout << "\nERROR in opening amplifier:\t" << nRes;
			return nRes;
		}
		// DevicePropertyID is enumerated in Amplifier_LIB.h
		nRes = amp.GetProperty(sSerialNumber, DevicePropertyID::DPROP_CHR_SerialNumber);
		if (nRes != AMP_OK)
		{
			std::cout << "\nERROR in GetProperty SerialNumber:\t" << nRes;
			return nRes;
		}
		nRes = amp.GetProperty(sType, DevicePropertyID::DPROP_CHR_Type);
		if (nRes != AMP_OK)
		{
			std::cout << "\nERROR in GetProperty Type:\t" << nRes;
			return nRes;
		}
		nRes = amp.Close();
		if (nRes != AMP_OK)
		{
			std::cout << "\nERROR in closing amplifier:\t" << nRes;
			return nRes;
		}
		pssAmpDetails.first = sType;
		pssAmpDetails.second = sSerialNumber;
		// print the results and store the details for later
		m_vpAmpDetails.push_back(pssAmpDetails);
		std::cout << "\n" <<
			"\t" << "Found Device: " << sType << " " << sSerialNumber;
	}
	int nIdx = 0;
	std::cout << "\n";
	return nIdx;
}

int SearchForAmps()
{

	int nInterfaceType = 2;

	// error codes enumerated in Amplifier_LIB.h
	int nRes;

	// container for Device address
	std::string sHWDeviceAddress = "";

	// container for interface type
	char hwi[20];
	switch (nInterfaceType)
	{
	case 3:
		strcpy_s(hwi, "SIM");
		break;
	case 2:
		strcpy_s(hwi, "BT");
		break;
	case 1:
		strcpy_s(hwi, "USB");
		break;
	default:
		strcpy_s(hwi, "ANY");
		break;
	}
	std::cout << "\nSearching for devices...";
	// AmplifierSDK call to enumerate connected devices:
	nRes = EnumerateDevices(hwi, sizeof(hwi), (const char*)sHWDeviceAddress.data(), 0);
	return nRes;
}

int SelectAmpFamily()
{

	int nRes;

	int nFamily = 0;

	// AmplifierSDK call to select amp family:
	nRes = SetAmplifierFamily((AmplifierFamily)nFamily);
	return nRes;
}

int main()
{


	std::cout << "\n\t***Brain Products LiveAmp LSL Application***\n\n" <<
		"\tPsychological and Brain Sciences Department\n\tTexas A&M University\n" <<
		"\tSupport Contact: moeinrazavi@tamu.edu\n";
	int nRes = 0;
	char try_again;

	amp.Close();

	nRes = SelectAmpFamily();
	nRes = SearchForAmps();
	while (nRes < 1)
	{
		std::cout << "\n\nCould not find LiveAmp Device";
		std::cout << "\nSearch again (y/n)? ";
		std::cout << "\n>> ";
		std::cin >> try_again;
		if (try_again == 'y') {
			nRes = SelectAmpFamily();
			nRes = SearchForAmps();
			continue;
		}
		else if (try_again == 'n') {
			return  0;
		}
		else {
			continue;
		}
	}
	nRes = DisplayAmpInfo(nRes);
	ConnectToAmp(nRes);

	std::vector<float> vfImpVals;
	
	ChangeSampleRate();  // Set Sampling Rate on 500 Hz.
	
	// int nChoice = 3;
	// first setup the amplifier and put it into acquisition mode
	RawDataHandler rdh(amp);
	amp.StartAcquisition(RM_NORMAL);

	// now parse the data (look into RawDataHanlers.h for details)
	// std::vector<std::vector<float>> vvfData;
	
	// double channel_data[23];
	//int nChoice = -1;
	// int nChoice = 0;
	// double channels[23];
	
	std::cout << "Now started streaming data to LSL...";
	std::cout << "\n>> ";
	while (true)
	{
		// rdh.ParseRawData(amp, vvfData);
		rdh.ParseRawData(amp);
		// int nChCnt = 0;
		// std::vector<float> vfData = vvfData[0];
		// outlet.push_sample(channel_data);
	}
	// finish up
	amp.StopAcquisition();
	
	// while (nChoice != 4)
	// {
		// std::cout << "Now started streaming data to LSL...";
		// std::cout << "\n>> ";
		// //std::cin >> nChoice;
		// switch (nChoice)
		// {
		// case 0:
			// ChangeSampleRate();
			// break;
		// case 1:
			// CheckImpedances(vfImpVals);
			// break;
		// case 2:
			// Record();
			// break;
		// case 3:
			// PrintChannelValues();
			// break;
		// case 4:
			// break;
		// }
	// }
	amp.Close();
	return 0;
}